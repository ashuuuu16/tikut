module moviebooking {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    opens com.example.hellofx to javafx.fxml;
    exports com.example.hellofx;
}
